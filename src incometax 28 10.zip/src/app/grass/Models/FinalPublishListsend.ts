export class finallistmaster {
    DRAFT_WAITING_MASTER_ID: any;
    MONTH: any;
    YEAR: any;
    RESIDENCE_TYPE_ID: any;
    CREATION_DATE_TIME: any;
    PUBLISH_DATE_TIME: any;
    FINAL_FILE_URL: any;
    PREFERENCE_END_DATE_TIME: any;
    PREFERENCE_START_DATE_TIME: any;
    DRAFT_LIST_MASTER_ID: any;
    PUBLISHER_ID: any;
    CUTOFFDATE: any;
}