export class FlatPreferenceadd{
    EMPLOYEE_ID:any;
    FLAT_REQUEST_ID:any;
    PREFERNCE_NO:any;
    CITY_ID:any;
    AREA_ID:any;
    BLOCK_ID:any;
    BUILDING_ID:any;
    FLOOR_ID:any;
    FLAT_ID:any;
    TYPE:any;
}