export class Roledetails {
    ID: any
    ROLE_ID: any
    FORM_ID:any
    SEQ_NO:any
    IS_ALLOWED:boolean=true
    FORM_NAME:string=''
    PARENT_FORM_NAME:string=''
    LINK:string=''
    CLIENT_ID:any
}

