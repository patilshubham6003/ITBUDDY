export class finalAllotmentdetails12{
    FINAL_ALLOTMENT_MASTER_ID: any;
    FLAT_ID: any;
    EMP_ID: any;
    ALLOTMENT_DATE_TIME: any;
    STATUS: any;
    REMARK: any;
}