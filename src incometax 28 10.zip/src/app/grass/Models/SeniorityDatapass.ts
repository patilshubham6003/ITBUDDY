export class senioritypass{
    ID!:number;
    MONTH = '';
    RESIDENCE_TYPE = ''
    RESIDENCE_TYPE_NAME = ''
    YEAR = ''
    FILE_URL = '';

    STEP_NO:number = 0;
    STATUS : any;
  }