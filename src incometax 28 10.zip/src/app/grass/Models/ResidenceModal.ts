export class ResidenceMaster {

    ID:number=0;          
    TYPE:string='';
    PAY_BILL_SECTION:string='';    
    STATUS:boolean=true; 
    SEQUENCE_NO:number=0 ;

}