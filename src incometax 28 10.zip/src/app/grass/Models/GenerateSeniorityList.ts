export class genertaeSenioritylist{
    ID:number = 0;
    RESIDENCE_TYPE:any;
    MONTH:any;
    YEAR:any;
    SEQUENCE_NO: number = 0;
    OBJ_DATETIME_PERIOD:any;
    FILE_URL : any;
    FINAL_FILE_URL:any;
}