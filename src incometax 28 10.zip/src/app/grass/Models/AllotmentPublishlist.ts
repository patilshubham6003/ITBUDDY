export class Allotmentpublishedlist {
  CLIENT_ID: any;
  CREATED_MODIFIED_DATE: any;
  CREATION_DATE_TIME: any;
  CREATOR_ID: any;
  FILE_URL: any;
  ID: any;
  IS_FINAL: boolean = false;
  MONTH: any;
  OBJ_END_DATE_TIME: any;
  DRAFT_ALLOTMENT_PUBLISH_DATE: any;
  OBJ_START_DATE_TIME: any;
  PREFERENCES_MASTER_ID: any;
  PUBLISHER_ID: any;
  PUBLISH_DATE_TIME: any;
  READ_ONLY: any;
  RESIDENCE_TYPE_ID: any;
  STEP_NO: any;
  YEAR: any;
  GRAAS_SIGNATURE_ID: any;
  NEW_SIGNATURE_ID: any;
  HRA_SIGNATURE_ID: any;
  HRA_ORDER_NO: any;
  DRAFT_ALLOT_ORDER_NO: any;
  FINAL_ALLOT_ORDER_NO: any;
  PHYSICAL_ORDER_NO: any;
}
