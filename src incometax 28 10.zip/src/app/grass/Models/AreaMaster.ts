export class Areamaster{
    ID:number = 0;
    CITY_ID:any;
    NAME:string = '';
    ADDRESS:string = '';
    LONGITUDE :string = '';
    LATITUDE :string = '';
    SEQUENCE_NO : number = 0;
    STATUS:boolean = true;
    SHORT_CODE:any
    CARETAKER_ID:any
}