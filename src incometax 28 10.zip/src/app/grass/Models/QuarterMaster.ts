export class QuarterMaster {

    ID: number = 0;
    ROLE_ID: number = 0;
    DATE_JOINING: any;
    PRESENT_RESENDENTIAL_ADDRESS: any;
    PRESENT_OFFICE_ADDRESS: any;
    DESIGNATION: any;
    OFFICER_CAST: any;
    JOINING_LETTER: any;
    JOINING_ALLOTMENT_YEAR: boolean = true;
    JOINING_ALLOTMENT_LETTER: any;
    BASIC_PAY: number = 0;
    GRADE_PAY: number = 0;
    PAY_LEVEL: any;
    GRADE_PAY_DRAWN_DATE: any;
    GRADE_PAY_DRAWN_LETTER: any
    EMOLUMENTS_DRAWN: any;
    ACCOMMODATION_SENIORITY_DATE: any;
    DATE_MIN_PAY_GOV: any;
    MOBILE_NO: string = '';
    IS_ACTIVE: boolean = true;
    PASSWORD: string = '';
    CLOUD_ID: string = '';
    CLIENT_ID: number = 0;
    ORGANIZATION_ID: number = 0;

}