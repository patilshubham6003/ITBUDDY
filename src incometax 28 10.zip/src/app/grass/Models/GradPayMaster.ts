export class GradPayMaster {

    ID: number = 0;
    QUARTER_ID: number = 0;
    AMOUNT: any = '';
    STATUS: boolean = true;
    RESIDENCE_TYPE_ID: number = 0;
    SEQUENCE_NO: number = 0;


}