export class QuarterMaster {

    ID: number = 0;

    NAME: string = '';

    RESIDENCE_TYPE_ID: any;

    AVAILABLE_STATUS: any;

    ROOM_TYPE: any;

    FLOOR_ID: any;

    SEQUENCE_NO: any;

    STATUS: boolean = true;

}