export class flatavailability{
    ID:number = 0;
    RESIDENCE_TYPE:any;
    MONTH:any;
    YEAR:any;
    SEQUENCE_NO: number = 0;
    FILE_URL : any;
}