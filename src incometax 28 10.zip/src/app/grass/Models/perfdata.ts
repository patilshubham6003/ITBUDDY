export class prefdata {

    ID: number = 0;
    PREFERENCES_MASTER_ID:any
    EMP_ID:any
    STEP_NO:any
    SUBMIT_DATE_TIME:any
    UPLOAD_DATE_TIME:any
    UPLOAD_URL:any
    IS_SUBMITTED:any
    ADD_DATE_TIME:any
    PRINT_DATE_TIME:any

}