export class CityMaster {
    ID:number=0;
    NAME:string='';
    // SEQUENCE_NO: number = 0;
    STATUS: boolean = true;
    SHORT_CODE:any
}