export class ObjectionMasterNew{
    DRAFT_WAITING_MASTER_ID:any;
    EMP_ID:any;
    OBJECTION:any;
    RAISE_OBJECTION_DATE_TIME:any;
    ACTION_STATUS:any;
    REMARK:any;
    RESOLVER_ID:any;
    FILE_URL:any;
}