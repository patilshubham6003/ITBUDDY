export class TempDetailsMaster{
    TEMP_WAITING_MASTER_ID:any;
    EMP_ID:any;
    CURRENT_SEQ:any;
    OLD_SEQ:any;
    REMARK:any;
    STATUS:any;
    tempDetailsArr : Array<any>;
}