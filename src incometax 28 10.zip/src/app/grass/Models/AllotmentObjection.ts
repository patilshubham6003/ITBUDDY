export class AllotmentObjection {
    EMPLOYEE_ID: any
    ALLOTMENT_LIST_ID: any
    REASON: string = '';
    RESOLVED_BY_ID: any;
    ATTACHMENT1: any;
    ATTACHMENT2: any;
    REQUEST_DATETIME: any;
    RESOLVED_DATETIME: any;
    REMARK: string = '';
    FLAT_REQUEST_ID: any;
    STATUS: string = '';
}