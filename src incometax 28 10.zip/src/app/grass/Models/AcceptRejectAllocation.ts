export class acceptrejectallocation{
    ID:number;
    INSPECTOR_REMARK:string;
    INSPECTOR_ID:any;
}