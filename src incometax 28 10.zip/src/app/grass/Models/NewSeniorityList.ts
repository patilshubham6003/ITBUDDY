export class newSeniorityist {
    ID: number = 0;
    RESIDENCE_TYPE_ID: any;
    MONTH: any;
    YEAR: any;
    DRAFT_LIST_MASTER_ID: any
    OBJ_START_DATE_TIME: any = new Date();
    OBJ_END_DATE_TIME: any;
    FILE_URL: any;
    FINAL_FILE_URL: any;
    PREFERANCE_ADDED_DATETIME: any
    PREFERENCE_END_DATE_TIME: any;
    PREFERANCE_PRINT_DATETIME: any
    PREFERENCE_START_DATE_TIME: any;
    PREFERANCE_UPLOAD_DATETIME: any;
    CREATOR_ID: any;
    TEMP_WAITING_ID: any;
}