export class Flatpreference{
    EMPLOYEE_ID : any;
    FLAT_REQUEST_MASTER_ID : any;
    SERIAL_NO : any;
    TYPE_OF_RESIDENCE : any;
    GRADE_PAY: any;
    DATE_OF_JOINING: any;
    DATE_MIN_PAY_GOV: any;
}