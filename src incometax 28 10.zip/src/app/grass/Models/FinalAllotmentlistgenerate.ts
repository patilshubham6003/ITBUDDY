export class FinalAllotmentlist{
    DRAFT_ALLOTMENT_MASTER_ID:any;
    MONTH:any;
    YEAR:any;
    RESIDENCE_TYPE_ID:any;
    CREATION_DATE_TIME:any;
    FILE_URL:any;
    PUBLISH_DATE_TIME:any;
    PUBLISHER_ID:any;
    // AGE:any;
}