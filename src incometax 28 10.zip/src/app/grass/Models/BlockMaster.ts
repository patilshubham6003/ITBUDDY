export class BlockMaster{
    ID: number = 0;
    AREA_ID: any;
    NAME: string = '';
    STATUS: boolean = true;
    SEQUENCE_NO: number = 0;
}