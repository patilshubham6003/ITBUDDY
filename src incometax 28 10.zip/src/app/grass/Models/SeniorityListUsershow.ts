export class SeniorityListUsershow{
    RESIDENCE_TYPE:any;
}