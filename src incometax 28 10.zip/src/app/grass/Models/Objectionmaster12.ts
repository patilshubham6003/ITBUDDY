export class ObjectionMaster12 {
    DRAFT_WAITING_MASTER_ID: any;
    EMP_ID: any;
    OBJECTION: any;
    RAISE_OBJECTION_DATE_TIME: any;
    ACTION_STATUS: any;
    REMARK: any;
    RESOLVER_ID: any;
    FILE_URL: any;
    EMPLOYEE_CODE: any;
    EMPLOYEE_NAME: any;
    DESIGNATION: any;
    RESOLVED_DATE_TIME: any;
}