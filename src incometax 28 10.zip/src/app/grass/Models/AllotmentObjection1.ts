
export class AllotmentObjection1 {
    DRAFT_ALLOTMENT_ID: any;
    EMP_ID: any;
    OBJECTION: any;
    RAISE_OBJECTION_DATE_TIME: any;
    ACTION_STATUS: any;
    REMARK: any;
    RESOLVER_ID: any;
    FILE_URL: any;
    EMPLOYEE_NAME: any
    EMPLOYEE_CODE: any
    DESIGNATION: any
}