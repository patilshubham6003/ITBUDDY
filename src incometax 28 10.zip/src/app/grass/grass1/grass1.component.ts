import { Component } from '@angular/core';

@Component({
  selector: 'app-grass1',
  templateUrl: './grass1.component.html',
  styleUrls: ['./grass1.component.css']
})
export class Grass1Component {

}
