export class BuildingMaster {
  ID: number = 0;
  NAME: string = '';
  LONGITUDE: string = '';
  LATITUDE: string = '';
  STATUS: boolean = true;
  ADDRESS: any;
  SEQUENCE_NO: any;
  NO_FLOORS: any;
  AREA_ID: any;
  SHORT_CODE: any;
  USER_ID: any;
}
