import { Component } from '@angular/core';

@Component({
  selector: 'app-usercontact-master',
  templateUrl: './usercontact-master.component.html',
  styleUrls: ['./usercontact-master.component.css']
})
export class UsercontactMasterComponent {

}
