import { Component } from '@angular/core';

@Component({
  selector: 'app-cmsfileuploadlist',
  templateUrl: './cmsfileuploadlist.component.html',
  styleUrls: ['./cmsfileuploadlist.component.css']
})
export class CmsfileuploadlistComponent {

}
