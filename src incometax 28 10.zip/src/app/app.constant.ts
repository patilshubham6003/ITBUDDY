// // IMITHRA url

// export const appkeys = {
//   gmUrl: 'https://gm.tecpool.in:8079/',
//   baseUrl: 'https://imithra.uvtechsoft.com:9798/',
//   url: 'https://imithra.uvtechsoft.com:9798/api/',
//   imgUrl: 'https://imithra.uvtechsoft.com:9798/upload/',
//   imgUrl1: 'https://imithra.uvtechsoft.com:9798/upload/',
//   retriveimgUrl: 'https://imithra.uvtechsoft.com:9798/static/',
// };
// export const grass = {
//   gmUrl: 'https://gm.tecpool.in:8078/',
//   baseUrl: 'https://imithra.uvtechsoft.com:9798/',
//   url: 'https://imithra.uvtechsoft.com:9798/api/',
//   imgUrl: 'https://imithra.uvtechsoft.com:9798/upload/',
//   retriveimgUrl: 'https://imithra.uvtechsoft.com:9798/static/',
// key:'itbuddy'
// };

// export const appkeysMedical = {
//   gmUrl: 'https://gm.tecpool.in:8078/',
//   baseUrl: 'https://imithra.uvtechsoft.com:9798/',
//   url: 'https://imithra.uvtechsoft.com:9798/api/',
//   imgUrl: 'https://imithra.uvtechsoft.com:9798/api/upload/',
//   imgUrl1: 'https://imithra.uvtechsoft.com:9798/upload/',
//   retriveimgUrl: 'https://imithra.uvtechsoft.com:9798/static/',
// };

// MITHRA url
export const appkeys = {
  gmUrl: 'https://gm.tecpool.in:8079/',
  baseUrl: 'https://itbuddyadmin.uvtechsoft.com:9450/',
  url: 'https://itbuddyadmin.uvtechsoft.com:9450/api/',
  imgUrl: 'https://itbuddyadmin.uvtechsoft.com:9450/upload/',
  imgUrl1: 'https://itbuddyadmin.uvtechsoft.com:9450/upload/',
  retriveimgUrl: 'https://itbuddyadmin.uvtechsoft.com:9450/static/',
};

export const grass = {
  gmUrl: 'https://gm.tecpool.in:8078/',
  baseUrl: 'https://itbuddyadmin.uvtechsoft.com:9450/',
  url: 'https://itbuddyadmin.uvtechsoft.com:9450/api/',
  imgUrl: 'https://itbuddyadmin.uvtechsoft.com:9450/upload/',
  retriveimgUrl: 'https://itbuddyadmin.uvtechsoft.com:9450/static/',
  key: 'itbuddy',
};

export const appkeysMedical = {
  gmUrl: 'https://gm.tecpool.in:8078/',
  baseUrl: 'https://itbuddyadmin.uvtechsoft.com:9450/',
  url: 'https://itbuddyadmin.uvtechsoft.com:9450/api/',
  imgUrl: 'https://itbuddyadmin.uvtechsoft.com:9450/api/upload/',
  imgUrl1: 'https://itbuddyadmin.uvtechsoft.com:9450/upload/',
  retriveimgUrl: 'https://itbuddyadmin.uvtechsoft.com:9450/static/',
};

// LIVE Income tax url
// export const appkeys = {
//   // gmUrl: 'https://gm.tecpool.in:8079/',
//   baseUrl: 'https://incometaxmumbai.gov.in:9450/',
//   url: 'https://incometaxmumbai.gov.in:9450/api/',
//   imgUrl: 'https://incometaxmumbai.gov.in:9450/upload/',
//   imgUrl1: 'https://incometaxmumbai.gov.in:9450/upload/',
//   retriveimgUrl: 'https://incometaxmumbai.gov.in:9450/static/',
// };

// export const grass = {
//   // gmUrl: 'https://gm.tecpool.in:8078/',
//   baseUrl: 'https://incometaxmumbai.gov.in:9450/',
//   url: 'https://incometaxmumbai.gov.in:9450/api/',
//   imgUrl: 'https://incometaxmumbai.gov.in:9450/upload/',
//   retriveimgUrl: 'https://incometaxmumbai.gov.in:9450/static/',
// key:'incometax'
// };

// export const appkeysMedical = {
//   // gmUrl: 'https://gm.tecpool.in:8078/',
//   baseUrl: 'https://incometaxmumbai.gov.in:9450/',
//   url: 'https://incometaxmumbai.gov.in:9450/api/',
//   imgUrl: 'https://incometaxmumbai.gov.in:9450/api/upload/',
//   imgUrl1: 'https://incometaxmumbai.gov.in:9450/upload/',
//   retriveimgUrl: 'https://incometaxmumbai.gov.in:9450/static/',
// };

// // // // local

// export const appkeys = {
//   gmUrl: 'http://gm.tecpool.in:8079/',
//   baseUrl: 'https://wnm884z0-9451.inc1.devtunnels.ms/',
//   url: 'https://wnm884z0-9451.inc1.devtunnels.ms/api/',
//   imgUrl: 'https://wnm884z0-9451.inc1.devtunnels.ms/upload/',
//   imgUrl1: 'https://wnm884z0-9451.inc1.devtunnels.ms/upload/',
//   retriveimgUrl: 'https://wnm884z0-9451.inc1.devtunnels.ms/static/',
// };

// export const grass = {
//   gmUrl: 'https://gm.tecpool.in:8078/',
//   baseUrl: 'https://wnm884z0-9451.inc1.devtunnels.ms/',
//   url: 'https://wnm884z0-9451.inc1.devtunnels.ms/api/',
//   imgUrl: 'https://wnm884z0-9451.inc1.devtunnels.ms/upload/',
//   retriveimgUrl: 'https://wnm884z0-9451.inc1.devtunnels.ms/static/',
//   key: 'itbuddy',
// };
// export const appkeysMedical = {
//   gmUrl: 'https://gm.tecpool.in:8078/',
//   baseUrl: 'https://wnm884z0-9451.inc1.devtunnels.ms/',
//   url: 'https://wnm884z0-9451.inc1.devtunnels.ms/api/',
//   imgUrl: 'https://wnm884z0-9451.inc1.devtunnels.ms/api/upload/',
//   imgUrl1: 'https://wnm884z0-9451.inc1.devtunnels.ms/upload/',
//   retriveimgUrl: 'https://wnm884z0-9451.inc1.devtunnels.ms/static/',
// };

// export const appkeys = {
//   gmUrl: 'http://gm.tecpool.in:8079/',
//   baseUrl: 'http://192.168.29.209:9450/',
//   url: 'http://192.168.29.209:9450/api/',
//   imgUrl: 'http://192.168.29.209:9450/upload/',
//   imgUrl1: 'http://192.168.29.209:9450/upload/',
//   retriveimgUrl: 'http://192.168.29.209:9450/static/',
// };

// export const grass = {
//   gmUrl: 'https://gm.tecpool.in:8078/',
//   baseUrl: 'http://192.168.29.209:9450/',
//   url: 'http://192.168.29.209:9450/api/',
//   imgUrl: 'http://192.168.29.209:9450/upload/',
//   retriveimgUrl: 'http://192.168.29.209:9450/static/',
// key:'itbuddy'
// };

// export const appkeysMedical = {
//   gmUrl: 'https://gm.tecpool.in:8078/',
//   baseUrl: 'http://192.168.29.209:9450/',
//   url: 'http://192.168.29.209:9450/api/',
//   imgUrl: 'http://192.168.29.209:9450/api/upload/',
//   imgUrl1: 'http://192.168.29.209:9450/upload/',
//   retriveimgUrl: 'http://192.168.29.209:9450/static/',
// };

// "buildOptimizer": false,
// "optimization": false,
// "vendorChunk": true,
// "extractLicenses": false,
// "sourceMap": true,
// "namedChunks": true
