export class categoryMaster{
    CLIENT_ID: number;
    ID: number;
    NAME: string;
    IS_ACTIVE: boolean;
}