export class User {
  ID: number;
  CLIENT_ID: number;
  NAME: string;
  EMAIL_ID: string;
  MOBILE_NUMBER: string;
  IS_ACTIVE: boolean;
  PASSWORD: string;
  ROLE_DATA: any = [];
  USER_ID: any;
  DDO_ID: any;
  RESIDENCE_TYPE_IDS: any = [];
  PARENT_USER_ID:any;
}
