export class Form {
    ID:number;
    NAME:string;
    LINK:string;
    PARENT_ID:number;
    SERVICE_ID:any
    ICON:string;
    CLIENT_ID: number;
}
