import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-cmsview',
  templateUrl: './cmsview.component.html',
  styleUrls: ['./cmsview.component.css'],
})
export class CmsviewComponent {
  @Input() empdataaaa: any;
  @Input() dataPostingList: any;
  @Input() servicedata: any;
  @Input() drawerClose: any;
  calculateDateDifference(fromDate: string, toDate: string): any {
    if (
      fromDate != null &&
      fromDate != '' &&
      fromDate != undefined &&
      toDate != null &&
      toDate != '' &&
      toDate != undefined
    ) {
      const startDate = new Date(fromDate);
      const endDate = new Date(toDate);

      let years = endDate.getFullYear() - startDate.getFullYear();
      let months = endDate.getMonth() - startDate.getMonth();
      let days = endDate.getDate() - startDate.getDate();

      if (days < 0) {
        months -= 1;
        const prevMonth = new Date(
          endDate.getFullYear(),
          endDate.getMonth(),
          0
        );
        days += prevMonth.getDate();
      }

      if (months < 0) {
        years -= 1;
        months += 12;
      }
      return years + ' y ' + months + ' M ' + days + 'd';
    } else {
      return '';
    }
  }
}
